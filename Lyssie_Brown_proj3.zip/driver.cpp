/*
Name: Lyssie Brown
Filename: driver.cpp
Date: 11/30/2022
Purpose: Driver for programming project 3. Reads files formatted like pp3.txt and outputs to terminal the running result of the assembly instructions contained within the file(s).
*/
#ifndef DRIVER_CPP
#define DRIVER_CPP

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <unordered_map>
#include <algorithm>

const std::string red("\033[0;31m");
const std::string green("\033[0;32m");
const std::string yellow("\033[0;33m");
const std::string cyan("\033[0;36m");
const std::string magenta("\033[0;35m");
const std::string reset("\033[0m");



void printRegisters(int len, uint32_t registerArray[]);
uint32_t convertToDec(std::string s);
uint32_t add(uint32_t i1, uint32_t i2);
uint32_t sub(uint32_t i1, uint32_t i2);
//naming this function 'and' causes an error
uint32_t andNew(uint32_t i1, uint32_t i2);
uint32_t orr(uint32_t i1, uint32_t i2);
//namig this function 'xor' causes an error
uint32_t xorNew(uint32_t i1, uint32_t i2);
uint32_t asr(uint32_t i1, uint32_t i2);
uint32_t lsr(uint32_t i1, uint32_t i2);
uint32_t lsl(uint32_t i1, uint32_t i2);

int main(int argc, char* argv[]) {
	//unordered map for any switch statements
	std::unordered_map<std::string, int> umap;
	umap["MOV"] = 1; //not done
	umap ["ADD"] = 2; //not done
	umap["SUB"] = 3; //not done
	umap["AND"] = 4; //not done
	umap["ORR"] = 5; //not done
	umap["XOR"] = 6; //not done
	umap["ASR"] = 7; //not done
	umap["LSR"] = 8; //not done
	umap["LSL"] = 9; //not done


	
	//initialize all registers to 0
	uint32_t registerFile[8] = {0};
	
	std::vector<std::string> filenames;
	std::ifstream f;
	if (argc > 1) {
		std::cout << "Filename(s) supplied: " << std::endl;
		for (int i=1; i < argc; i++) {
			std::cout << argv[i] << std::endl;
		}
		//
		for (int i=1; i < argc; i++) {
			std::cout << "Attempting to open " << argv[i] << "..." << std::endl;
			f.open(argv[i]);
			if (f.is_open()) {
				std::cout << green << "Opened " << argv[i] << "." << reset << std::endl;
				
				filenames.push_back(argv[i]);
				}
			else {
				std::cout << red << "Unable to open " << argv[i] << "." << reset << std::endl;
			}
			f.close(); //close file
		}
	}

	//Begin file reading
	//Open files using filename vector.
	for (int i=0; i < filenames.size(); i++) {
		f.open(filenames[i]);
		if (f.is_open()) {
			std::cout << green << "Processing " << filenames[i] << ":" << reset << std::endl;
			std::string line;
			
			//Use getline and stringstream to get both the entire line and the individual words,
			//separated by spaces, in order to execute the command specified
			//in the line.

			//for each line in file
			while(getline(f, line))
			{
				std::cout << line << std::endl;
				std::vector<std::string> words;
				std::stringstream l(line);
				std::string word;
				while (l>>word) {
					words.push_back(word);
				}
				//figure out ALU_OP and stuff
				std::string ALU_OP = words[0];
				transform(ALU_OP.begin(), ALU_OP.end(), ALU_OP.begin(), ::toupper);
				int destReg = std::stoi(words[1].substr(1, words[1].size() - 1));
				std::string immWithout0x;
				uint32_t input1;
				uint32_t input2;
				uint32_t opReg1;
				uint32_t opReg2;
				//initialize stuff and do mov as necessary
				switch(umap[ALU_OP]) {
					case 1: //mov
						//given as an immediate
						//first remove the #0x from the number
						immWithout0x = words[2].substr(3, words[2].size());
						//then convert it to decimal and store in the destination register
						registerFile[destReg] = convertToDec(immWithout0x);						
						break;
					case 2: //add
					case 3: //sub
					case 4: //and
					case 5: //orr
					case 6: //xor
						opReg1 = std::stoi(words[2].substr(1, words[2].size()));
						opReg2 = std::stoi(words[3].substr(1, words[3].size()));
						input1 = registerFile[opReg1];
						input2 = registerFile[opReg2];
						break;
					case 7: //asr
					case 8: //lsr
					case 9: //lsl
						opReg1 = std::stoi(words[2].substr(1, words[2].size()));
						input1 = registerFile[opReg1];
						input2 = std::stoi(words[3].substr(1, words[3].size()));;				
					break;
				}

				switch(umap[ALU_OP]) {
					case 2: //add
						registerFile[destReg] = add(input1, input2);
						break;
					case 3: //sub
						registerFile[destReg] = sub(input1, input2);
						break;
					case 4: //and
						registerFile[destReg] = andNew(input1, input2);
						break;
					case 5: //orr
						registerFile[destReg] = orr(input1, input2);
						break;
					case 6: //xor
						registerFile[destReg] = xorNew(input1, input2);
						break;
					case 7: //asr
						registerFile[destReg] = asr(input1, input2);
						break;
					case 8: //lsr
						registerFile[destReg] = lsr(input1, input2);
						break;
					case 9: //lsl
						registerFile[destReg] = lsl(input1, input2);
						break;
					break;
				}

				printRegisters(8, registerFile);

			}
		}
	}

	return 0;
}

//helper functions, including printing and the various operations

void printRegisters(int len, uint32_t registerArray[]) {
	std::cout << magenta;
	
	for (int i=0; i<len; i++) {
		std::cout << "R" << std::dec << i << ": 0x" << std::uppercase <<  std::hex << registerArray[i] << " ";
	}

	std::cout << reset << std::nouppercase << std::endl;
	
}

uint32_t convertToDec(std::string s) {
	std::stringstream converter;
	converter << std::hex << s;
	uint32_t result;
	converter >> result;
	std::cout << std::dec;	
	return result;
}

uint32_t add(uint32_t i1, uint32_t i2) {
	return i1+i2;
}
uint32_t sub(uint32_t i1, uint32_t i2) {
	return i1-i2;
}
//naming this function 'and' causes an error
uint32_t andNew(uint32_t i1, uint32_t i2) {
	return i1&i2;
}
uint32_t orr(uint32_t i1, uint32_t i2) {
	return i1|i2;
}
//namig this function 'xor' causes an error
uint32_t xorNew(uint32_t i1, uint32_t i2) {
	return i1^i2;
}
uint32_t asr(uint32_t i1, uint32_t i2) {
	int32_t i1Signed;
	std::stringstream s;
	s << i1;
	s >> i1Signed;
	i1Signed = i1Signed >> i2;
	s << i1Signed;
	s >> i1;
	return i1;
}
uint32_t lsr(uint32_t i1, uint32_t i2) {
	return i1 >> i2;
}
uint32_t lsl(uint32_t i1, uint32_t i2) {
	return i1 << i2;
}



#endif