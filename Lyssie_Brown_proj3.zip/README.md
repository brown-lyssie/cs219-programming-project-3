# Virtual Machine

## How To Use
Type
```
make
```
to create the executable called `pp3`.
To run, type `./pp3` followed by the filenames you would like to read. For example, to read the file that was supplied for Project 3,
```
./pp3 pp3.txt
```
To read multiple files, type
```
./pp3 filename1 filename2
```
or any number of files. Files that cannot be opened will not be read.


**Note:** No other testing files have been added to the directory. 

## Overall Functionality

The program takes in filenames via the command line (see "How To Use") and can read text files that are formatted in a way that mimics assembly code. The program reads and outputs each line from the text file and, on the next line, outputs the current status of registers r0 - r7.

**Note:** Values larger than uint32_t will not be able to be stored in their entirety. Thus, carry values for operations that result in values larger than uint32_t will be discarded without warning.

### Available Functions

* MOV [Reg], [Imm]
* ADD [Reg], [Reg], [Reg]
* SUB [Reg], [Reg], [Reg]
* AND [Reg], [Reg], [Reg]
* ORR [Reg], [Reg], [Reg]
* XOR [Reg], [Reg], [Reg]
* ASR [Reg], [Reg], [Imm]
* LSR [Reg], [Reg], [Imm]
* LSL [Reg], [Reg], [Imm]

## Output

The output will be in the terminal. It will contain the line of the file supplied, followed by a colored line that contains the values of register r0 - r7. For example, the first line of `pp3.txt` results in the output:
~~~
MOV R1, #0x72DF9901
R0: 0x0 R1: 0x72DF9901 R2: 0x0 R3: 0x0 R4: 0x0 R5: 0x0 R6: 0x0 R7: 0x0 
~~~

## Directory Structure

The `driver.cpp` file has the main function. Within `driver.cpp` is the main function as well as all helper functions, including a function to print all registers and all required